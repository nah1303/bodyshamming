from flask import Flask, render_template, request, jsonify
import json
import os

app = Flask(__name__)

# Mock AI evaluation logic
def analyze_body_safe_text(text, location="Chưa rõ", frequency="Chưa xác định"):
    lower = text.lower()
    severe_keywords = ['heo', 'béo', 'mập', 'xấu', 'dị', 'lùn', 'đen', 'quái', 'gầy cừu', 'chê', 'dè bỉu']
    positive_keywords = ['xinh', 'đẹp', 'hợp', 'tốt', 'dễ thương', 'tuyệt']

    has_negative = any(k in lower for k in severe_keywords)
    has_positive = any(k in lower for k in positive_keywords)

    if not has_negative and (has_positive or len(lower) < 25):
        return {
            "level": "L0",
            "title": "Giao tiếp phù hợp & tôn trọng",
            "description": "Nội dung thể hiện sự tôn trọng, khen ngợi tích cực hoặc không có dấu hiệu công kích ngoại hình.",
            "evidence": [
                "Sử dụng ngôn ngữ lịch sự, mang tính xây dựng hoặc động viên.",
                "Không xuất hiện các từ ngữ miệt thị hay dán nhãn ngoại hình.",
                "Tạo năng lượng tích cực cho môi trường học đường."
            ],
            "impact": "Giúp đối phương cảm thấy vui vẻ, tự tin và tăng cường tình bạn gắn kết.",
            "advice_speaker": "Tiếp tục duy trì thái độ tích cực và lời nói tử tế.",
            "advice_bystander": "Lan tỏa sự tôn trọng này đến các bạn xung quanh.",
            "advice_escalate": "Không cần can thiệp.",
            "quote": '"Một lời nói tử tế có thể làm bừng sáng cả ngày của ai đó."'
        }
    elif has_negative and frequency == "Nhiều lần" and (location in ["Trong giờ ra chơi", "Trên mạng xã hội"]):
        return {
            "level": "L3",
            "title": "Nghiêm trọng – Có yếu tố làm nhục/bắt nạt",
            "description": "Hành vi miệt thị diễn ra lặp đi lặp lại hoặc trước tập thể đông người, có nguy cơ bắt nạt học đường.",
            "evidence": [
                "Xuất hiện từ ngữ xúc phạm ngoại hình mang tính đe dọa hoặc làm nhục.",
                "Hành vi có tính chất lặp lại nhiều lần.",
                "Xảy ra công khai khiến đối phương rơi vào thế yếu."
            ],
            "impact": "Gây tổn thương tâm lý sâu sắc, khiến đối phương sợ hãi, khóc nấc, muốn bỏ học hoặc lo âu kéo dài.",
            "advice_speaker": "Chấm dứt ngay lập tức hành vi công kích và chịu trách nhiệm về lời nói của mình.",
            "advice_bystander": "Dũng cảm lên tiếng yêu cầu dừng lại và báo ngay cho GVCN.",
            "advice_escalate": "Cần sự can thiệp trực tiếp từ Ban giám hiệu, Ban tư vấn học đường và Phụ huynh.",
            "quote": '"Bắt nạt không bao giờ là trò đùa. Hãy đứng về phía lẽ phải và sự tôn trọng."'
        }
    elif has_negative:
        return {
            "level": "L2",
            "title": "Có dấu hiệu miệt thị ngoại hình",
            "description": "Nội dung chứa từ ngữ chê bai ngoại hình, đặc biệt khi diễn ra trước tập thể có thể gây tổn thương.",
            "evidence": [
                "Có từ ngữ chê bai, dán nhãn về vóc dáng, làn da, chiều cao...",
                "Dễ làm người nghe cảm thấy xấu hổ hoặc tổn thương.",
                "Cần chấn chỉnh để tránh leo thang thành bắt nạt."
            ],
            "impact": "Có thể làm đối phương tự ti, ngại giao tiếp và mất niềm tin vào bạn bè.",
            "advice_speaker": "Dừng nhận xét gây tổn thương và xin lỗi chân thành.",
            "advice_bystander": "Không hùa theo cười đùa, nhắc nhở bạn nói lời tử tế.",
            "advice_escalate": "Nếu hành vi còn tiếp diễn, hãy nhờ giáo viên chủ nhiệm hỗ trợ.",
            "quote": '"Ngoại hình chỉ là một phần nhỏ, tâm hồn và trí tuệ mới làm nên giá trị thực sự."'
        }
    else:
        return {
            "level": "L1",
            "title": "Nhạy cảm – Cần thêm ngữ cảnh",
            "description": "Nội dung có yếu tố nhạy cảm, phụ thuộc nhiều vào thái độ, tông giọng và sự đồng ý của người nghe.",
            "evidence": [
                "Từ ngữ có thể bị hiểu lầm tùy thuộc vào cách xưng hô.",
                "Chưa đủ căn cứ khẳng định có mục đích xúc phạm hay không.",
                "Cần chú ý thái độ phản ứng của đối phương."
            ],
            "impact": "Người nghe có thể cảm thấy băn khoăn hoặc hơi chạnh lòng nếu không thân thiết.",
            "advice_speaker": "Hỏi lại cảm xúc đối phương và điều chỉnh cách giao tiếp.",
            "advice_bystander": "Quan sát phản ứng của bạn để hỗ trợ kịp thời.",
            "advice_escalate": "Trao đổi nhẹ nhàng giữa hai bên để hiểu rõ ý định.",
            "quote": '"Sự tinh tế trong giao tiếp bắt đầu từ việc lắng nghe cảm xúc của người khác."'
        }

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/analyze', methods=['POST'])
def analyze():
    data = request.json or {}
    text = data.get('text', '')
    location = data.get('location', 'Chưa rõ')
    frequency = data.get('frequency', 'Chưa xác định')
    
    result = analyze_body_safe_text(text, location, frequency)
    return jsonify(result)

if __name__ == '__main__':
    app.run(debug=True, port=5000)
